<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'you', 'yan', 'gu', 'gu', 'bei', 'han', 'suo', 'chun', 'yi', 'ai', 'jia', 'tu', 'xian', 'wan', 'li', 'xi',
  0x10 => 'tang', 'zuo', 'qiu', 'che', 'wu', 'zao', 'ya', 'dou', 'qi', 'di', 'qin', 'ma', 'mo', 'gong', 'dou', 'qu',
  0x20 => 'lao', 'liang', 'suo', 'zao', 'huan', 'lang', 'sha', 'ji', 'zuo', 'wo', 'feng', 'jin', 'hu', 'qi', 'shou', 'wei',
  0x30 => 'shua', 'chang', 'er', 'li', 'qiang', 'an', 'ze', 'yo', 'nian', 'yu', 'tian', 'lai', 'sha', 'xi', 'tuo', 'hu',
  0x40 => 'ai', 'zhao', 'nou', 'ken', 'zhuo', 'zhuo', 'shang', 'di', 'heng', 'lin', 'a', 'cai', 'xiang', 'tun', 'wu', 'wen',
  0x50 => 'cui', 'sha', 'gu', 'qi', 'qi', 'tao', 'dan', 'dan', 'ye', 'zi', 'bi', 'cui', 'chuai', 'he', 'ya', 'qi',
  0x60 => 'zhe', 'fei', 'liang', 'xian', 'pi', 'sha', 'la', 'ze', 'ying', 'gua', 'pa', 'zhe', 'se', 'zhuan', 'nie', 'guo',
  0x70 => 'luo', 'yan', 'di', 'quan', 'chan', 'bo', 'ding', 'lang', 'xiao', 'ju', 'tang', 'chi', 'ti', 'an', 'jiu', 'dan',
  0x80 => 'ka', 'yong', 'wei', 'nan', 'shan', 'yu', 'zhe', 'la', 'jie', 'hou', 'han', 'die', 'zhou', 'chai', 'wai', 'nuo',
  0x90 => 'yu', 'yin', 'za', 'yao', 'o', 'mian', 'hu', 'yun', 'chuan', 'hui', 'huan', 'huan', 'xi', 'he', 'ji', 'kui',
  0xA0 => 'zhong', 'wei', 'sha', 'xu', 'huang', 'duo', 'nie', 'xuan', 'liang', 'yu', 'sang', 'chi', 'qiao', 'yan', 'dan', 'pen',
  0xB0 => 'can', 'li', 'yo', 'zha', 'wei', 'miao', 'ying', 'pen', 'bu', 'kui', 'xi', 'yu', 'jie', 'lou', 'ku', 'zao',
  0xC0 => 'hu', 'ti', 'yao', 'he', 'a', 'xiu', 'qiang', 'se', 'yong', 'su', 'hong', 'xie', 'ai', 'suo', 'ma', 'cha',
  0xD0 => 'hai', 'ke', 'da', 'sang', 'chen', 'ru', 'sou', 'wa', 'ji', 'pang', 'wu', 'qian', 'shi', 'ge', 'zi', 'jie',
  0xE0 => 'luo', 'weng', 'wa', 'si', 'chi', 'hao', 'suo', 'Jia ', 'hai', 'suo', 'qin', 'nie', 'he', 'zhi', 'sai', 'n',
  0xF0 => 'ge', 'na', 'dia', 'ai', 'qiang', 'tong', 'bi', 'ao', 'ao', 'lian', 'zui', 'zhe', 'mo', 'sou', 'sou', 'tan',
];
